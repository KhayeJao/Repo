<?php

namespace backend\controllers;

use common\models\Menu;
use common\models\MenuSearch;
use yii\web\Controller;
use yii\web\HttpException;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use yii\helpers\Url;
use dmstr\bootstrap\Tabs;
use Yii;
use yii\helpers\CommonHelper;

/**
 * MenuController implements the CRUD actions for Menu model.
 */
class MenuController extends Controller {

    /**
     * @var boolean whether to enable CSRF validation for the actions in this controller.
     * CSRF validation is enabled only when both this property and [[Request::enableCsrfValidation]] are true.
     */
    public $enableCsrfValidation = false;

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['index', 'view', 'create', 'update', 'delete'],
                        'roles' => ['@']
                    ]
                ]
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function beforeAction($action) {
        if (parent::beforeAction($action)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Lists all Menu models.
     * @return mixed
     */
    public function actionIndex() {
        $params = Yii::$app->request->queryParams;
        if ($params) {
            $id = $params['MenuSearch']['restaurant_id'];
            if ($id) {
                CommonHelper::restaurantAccessControl($id);
                $searchModel = new MenuSearch;
                $dataProvider = $searchModel->search($_GET);

                Tabs::clearLocalStorage();

                Url::remember();
                \Yii::$app->session['__crudReturnUrl'] = null;

                return $this->render('index', [
                            'dataProvider' => $dataProvider,
                            'searchModel' => $searchModel,
                ]);
            }
        } else {
            $this->redirect(Url::previous());
        }
    }

    /**
     * Displays a single Menu model.
     * @param integer $id
     *
     * @return mixed
     */
    public function actionView($id) {
        $resolved = \Yii::$app->request->resolve();
        $resolved[1]['_pjax'] = null;
        $url = Url::to(array_merge(['/' . $resolved[0]], $resolved[1]));
        \Yii::$app->session['__crudReturnUrl'] = Url::previous();
        Url::remember($url);
        Tabs::rememberActiveState();

        return $this->render('view', [
                    'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Menu model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $params = Yii::$app->request->queryParams;
        if ($params) {
            $id = $params['Menu']['restaurant_id'];
            if ($id) {
                CommonHelper::restaurantAccessControl($id);
                $model = new Menu;
                try {
                    if ($model->load(Yii::$app->request->post())) {
                        // process uploaded image file instance
                        $image = $model->uploadImage();
                        if ($model->save()) {
                            // upload only if valid uploaded file instance found
                            if ($image !== false) {
                                $path = $model->getImageFile();
                                $image->saveAs($path);
                                $destinationPath = Yii::$app->params['MImagePath'] . "resize/" . $model->image;
                                CommonHelper::resize($path, $destinationWidth = 250, $destinationHeight = 250, $destinationPath);
                            }


                            return $this->redirect(Url::previous());
                            //return $this->redirect(['index', 'modId' => $model->modId]);
                        } else {
                            // error
                        }
                    } elseif (!\Yii::$app->request->isPost) {
                        $model->load($_GET);
                    }
                } catch (\Exception $e) {
                    $msg = (isset($e->errorInfo[2])) ? $e->errorInfo[2] : $e
                                    ->getMessage();
                    $model->addError('_exception', $msg);
                }
//                try {
//                    if ($model->load($_POST) && $model->save()) {
//                        return $this->redirect(Url::previous());
//                    } elseif (!\Yii::$app->request->isPost) {
//                        $model->load($_GET);
//                    }
//                } catch (\Exception $e) {
//                    $msg = (isset($e->errorInfo[2])) ? $e->errorInfo[2] : $e->getMessage();
//                    $model->addError('_exception', $msg);
//                }
                return $this->render('create', ['model' => $model]);
            }
        } else {
            $this->redirect(Url::previous());
        }
    }

    /**
     * Updates an existing Menu model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $oldFile = $model->getImageFile();
        $oldRFile = $model->getResizeImageFile();
        $oldAvatar = $model->image;
        if ($model->load(Yii::$app->request->post())) {
            // process uploaded image file instance
            $image = $model->uploadImage();
            // revert back if no valid file instance uploaded
            if ($image === false) {
                $model->image = $oldAvatar;
            }
            if ($model->save()) {
                // upload only if valid uploaded file instance found
                if ($image !== false) {  // delete old and overwrite
                    if (file_exists($oldFile))
                        unlink($oldFile);
                    if (file_exists($oldRFile))
                        unlink($oldRFile);
                    $path = $model->getImageFile();
                    $image->saveAs($path);

                    $destinationPath = Yii::$app->params['MImagePath'] . "resize/" . $model->image;
                    CommonHelper::resize($path, $destinationWidth = 250, $destinationHeight = 250, $destinationPath);
                }
                return $this->redirect(Url::previous());
                //return $this->redirect(['view', 'id' => $model->_id]);
            } else {
                // error in saving model
            }
        } else {
            return $this->render('update', ['model' => $model, 'restaurant_id' => $id]);
        }
//        if ($model->load($_POST) && $model->save()) {
//            $this->redirect(Url::previous());
//        } else {
//            return $this->render('update', [
//                        'model' => $model,
//            ]);
//        }
    }

    /**
     * Deletes an existing Menu model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        try {
            $model = $this->findModel($id);
            if ($model->delete()) {
                if (!$model->deleteImage()) {
                    Yii::$app->session->setFlash('error', 'Error deleting image');
                }
            }
        } catch (\Exception $e) {
            $msg = (isset($e->errorInfo[2])) ? $e->errorInfo[2] : $e->getMessage();
            \Yii::$app->getSession()->setFlash('error', $msg);
            return $this->redirect(Url::previous());
        }

        // TODO: improve detection
        $isPivot = strstr('$id', ',');
        if ($isPivot == true) {
            $this->redirect(Url::previous());
        } elseif (isset(\Yii::$app->session['__crudReturnUrl']) && \Yii::$app->session['__crudReturnUrl'] != '/') {
            Url::remember(null);
            $url = \Yii::$app->session['__crudReturnUrl'];
            \Yii::$app->session['__crudReturnUrl'] = null;

            $this->redirect($url);
        } else {
            $this->redirect(['index']);
        }
    }

    /**
     * Finds the Menu model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Menu the loaded model
     * @throws HttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Menu::findOne($id)) !== null) {
            return $model;
        } else {
            throw new HttpException(404, 'The requested page does not exist.');
        }
    }

    public static function makeDropDown($parents) {
        global $data;
        $data = array();
        $data['0'] = '-- ROOT --';
        foreach ($parents as $parent) {
            $data[$parent->id] = $parent->title;
            self::subDropDown($parent->id);
        }
        return $data;
    }

    public static function subDropDown($children, $space = '---') {
        global $data;
        $childrens = Menu::findAll(['parent_id' => $children]);
        foreach ($childrens as $child) {
            $data[$child->id] = $space . $child->title;
            self::subDropDown($child->id, $space . '---');
        }
    }

}
