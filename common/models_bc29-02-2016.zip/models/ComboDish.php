<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_combo_dish".
 */
class ComboDish extends \common\models\base\ComboDish
{
}
