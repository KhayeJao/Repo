<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_fav_dish".
 */
class FavDish extends \common\models\base\FavDish
{
}
