<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_dish".
 */
class Dish extends \common\models\base\Dish
{
}
