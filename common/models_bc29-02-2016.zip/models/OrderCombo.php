<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_order_combo".
 */
class OrderCombo extends \common\models\base\OrderCombo
{
}
