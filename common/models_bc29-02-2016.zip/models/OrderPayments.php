<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_order_payments".
 */
class OrderPayments extends \common\models\base\OrderPayments
{
}
