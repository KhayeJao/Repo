<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_cuisine".
 */
class Cuisine extends \common\models\base\Cuisine
{
}
