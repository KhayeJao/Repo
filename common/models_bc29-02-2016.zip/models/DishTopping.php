<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_dish_topping".
 */
class DishTopping extends \common\models\base\DishTopping
{
}
