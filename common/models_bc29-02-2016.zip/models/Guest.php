<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_guest".
 */
class Guest extends \common\models\base\Guest
{
}
