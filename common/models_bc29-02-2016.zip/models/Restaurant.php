<?php

namespace common\models;

use Yii;

/**

 * This is the model class for table "tbl_restaurant".

 */
class Restaurant extends \common\models\base\Restaurant {

}
