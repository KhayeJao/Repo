<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_topping".
 */
class Topping extends \common\models\base\Topping
{
}
