<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_table".
 */
class Table extends \common\models\base\Table
{
}
