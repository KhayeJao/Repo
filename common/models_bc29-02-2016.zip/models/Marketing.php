<?php

namespace common\models;

use Yii;
use yii\base\Model;

class Marketing extends \yii\db\ActiveRecord{
	public static function tableName() {
        return 'marketing';
        
    }
}
