<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_order_combo_dish".
 */
class OrderComboDish extends \common\models\base\OrderComboDish
{
}
