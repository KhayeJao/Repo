<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_service".
 */
class Template extends \common\models\base\Template
{
}
