<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_discount_key".
 */
class DiscountKey extends \common\models\base\DiscountKey
{
}
