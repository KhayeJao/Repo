<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_content".
 */
class Content extends \common\models\base\Content
{
}
