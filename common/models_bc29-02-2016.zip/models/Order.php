<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_order".
 */
class Order extends \common\models\base\Order
{
}
