<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_order_topping".
 */
class OrderTopping extends \common\models\base\OrderTopping
{
}
