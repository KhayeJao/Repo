<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_restaurant_services".
 */
class RestaurantServices extends \common\models\base\RestaurantServices
{
}
