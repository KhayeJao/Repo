<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_restaurant_review".
 */
class RestaurantReview extends \common\models\base\RestaurantReview
{
}
