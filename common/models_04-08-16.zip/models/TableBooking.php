<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_table_booking".
 */
class TableBooking extends \common\models\base\TableBooking
{
}
