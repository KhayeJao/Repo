<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_device".
 */
class Device extends \common\models\base\Device
{
}
