<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_restaurant_area".
 */
class RestaurantArea extends \common\models\base\RestaurantArea
{
}
