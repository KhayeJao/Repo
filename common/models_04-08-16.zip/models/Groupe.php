<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_Groupesms".
 */
class Groupe extends \common\models\base\Groupe
{
}
