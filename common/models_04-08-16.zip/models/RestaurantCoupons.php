<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_restaurant_coupons".
 */
class RestaurantCoupons extends \common\models\base\RestaurantCoupons
{
}
