<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_coupons".
 */
class Coupons extends \common\models\base\Coupons
{
}
