<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_menu".
 */
class Menu extends \common\models\base\Menu
{
}
