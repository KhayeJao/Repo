<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_table_booking_tables".
 */
class TableBookingTables extends \common\models\base\TableBookingTables
{
}
