<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_restaurant_images".
 */
class RestaurantImages extends \common\models\base\RestaurantImages
{
}
