<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_settings".
 */
class Settings extends \common\models\base\Settings
{
}
