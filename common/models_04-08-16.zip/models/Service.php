<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_service".
 */
class Service extends \common\models\base\Service
{
}
