<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "tbl_area".
 */
class Area extends \common\models\base\Area
{
}
