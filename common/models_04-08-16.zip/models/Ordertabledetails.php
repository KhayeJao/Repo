<?php

namespace common\models;

use Yii;

/**

 * This is the model class for table "tbl_Ordertablestatus".

 */
class Ordertabledetails extends \common\models\base\Ordertabledetails {

}
